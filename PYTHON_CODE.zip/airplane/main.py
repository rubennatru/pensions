# Rubén Navarro Trujillo #

import pytest


class airplane():

    def __init__(self, consumption, position, fuel_level):
        self.consumption = consumption
        self.position = position
        self.fuel_level = fuel_level

    def go_to(self,  future_pos):
        distance = ((future_pos[1] - self.position[1]) ^ 2) + ((future_pos[0] - self.position[0]) ^ 2)

        if self.fuel_level >= (distance * self.consumption):
            self.position = future_pos
            self.fuel_level = self.fuel_level - (distance * self.consumption)
            return True
        else:
            return False

    def refuel(self, amount):
        future_level = self.fuel_level + amount

        if (self.fuel_level < 100.0) & (future_level <= 100.0):
            self.fuel_level = future_level
        else:
            self.fuel_level = 100

        return self.fuel_level






if __name__ == '__main__':

    '''  
    
       ---  UNIT TEST 
    
    init_pos = (0,0)
    my_plane = airplane(3, init_pos, 100.0)
    pos = my_plane.position
    future_pos = (9,9)
    my_plane.go_to(future_pos)
    my_plane.refuel(50)
    
    
    '''

