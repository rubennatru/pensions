from main import airplane

''' TEST 1 '''

def test_init():

    cons = 3
    pos = (0,0)
    level = 100.0
    myplane = airplane(cons, pos, level)
    assert myplane.consumption == 3
    assert myplane.position == (0,0)
    assert myplane.fuel_level == 100.0


''' TEST 2.1 '''
def test_go_to1():
    cons = 3
    pos = (0,0)
    level = 100.0
    myplane = airplane(cons, pos, level)
    pos1 =  9
    pos2 = 9
    future_pos = (int(pos1), int(pos2))
    assert myplane.go_to(future_pos) == True



''' TEST 2.1 '''
def test_go_to2():
    cons = 3
    pos = (0,0)
    level = 100.0
    myplane = airplane(cons, pos, level)
    future_pos = (100,100)
    assert myplane.go_to(future_pos) == False


''' TEST 3 '''
def test_refuel():
    cons = 3
    pos = (0.0)
    level = 20.0
    myplane = airplane(cons, pos, level)
    assert myplane.refuel(100.0) == 100.0