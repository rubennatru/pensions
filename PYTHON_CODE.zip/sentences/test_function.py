import pytest

from main import make_sentence


''' TEST 1 '''
def test_make_sentence1():
    assert make_sentence(['Mark', 'Mary'], ['hates', 'loves'], ['apples', 'bananas']) == 'Mark hates apples. Mark hates bananas. Mark loves apples. Mark loves bananas. Mary hates apples. Mary hates bananas. Mary loves apples. Mary loves bananas.'


''' TEST 2 '''
def test_make_sentence2():
    assert make_sentence(["Vlad", "John"], ["drives"], ["car", "motorcycle", "bus"]) == "John drives bus. John drives car. John drives motorcycle. Vlad drives bus. Vlad drives car. Vlad drives motorcycle."



''' Error TEST 1 
def test_make_sentence3():
    assert make_sentence(["Michael"], ["rides"], ["bicycle", "motorcycle"]) == "Michael rides bicycle."

'''