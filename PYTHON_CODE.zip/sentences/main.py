# Rubén Navarro Trujillo #

def make_sentence(subject, verb, object):
    final_sentences = ''
    subject_sort = sorted(subject)
    verb_sort = sorted(verb)
    object_sort = sorted(object)

    for s in subject_sort:
        for v in verb_sort:
            for o in object_sort:
                current_sentence = s + ' ' + v + ' ' + o + '.'
                final_sentences += ' ' + current_sentence;

    final_sentences = final_sentences.lstrip()
    return final_sentences



if __name__ == '__main__':

    ''' 
    
    -----  UNIT TEST   ---- 
    
    chain1 = ['Rubén', 'Alberto']
    chain2 = ["salta", "corre"]
    chain3 = ["por la tarde", "por la mañana"]
    make_sentence(chain1, chain2, chain3) 
    
    '''
    


