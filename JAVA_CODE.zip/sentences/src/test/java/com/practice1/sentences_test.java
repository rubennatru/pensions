package com.practice1;
import java.util.Arrays;
import static org.junit.Assert.*;
import org.junit.Test;


public class sentences_test {

        @Test
        public void firstTest() {
            sentences sent = new sentences();
            assertEquals("Mark hates apples. Mark hates bananas. Mark loves apples. Mark loves bananas. Mary hates apples. Mary hates bananas. Mary loves apples. Mary loves bananas.", sent.generateSentences(Arrays.asList("Mary", "Mark"), Arrays.asList("loves", "hates"), Arrays.asList("apples", "bananas")));
        }

        @Test
        public void secondTest() {
            sentences sent = new sentences();
            assertEquals("John drives bus. John drives car. John drives motorcycle. Vlad drives bus. Vlad drives car. Vlad drives motorcycle.", sent.generateSentences(Arrays.asList("Vlad", "John"), Arrays.asList("drives"), Arrays.asList("car", "motorcycle", "bus")));
        }
}
