/* -----------------------
Rubén Navarro Trujillo
--------------------------*/

package com.practice1;
import sun.awt.X11.XSystemTrayPeer;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

public class sentences {
    public String generateSentences(List<String> subjects, List<String> verbs, List<String> objects) {

/*  UNIT TEST

        List<String> chain1;
        List<String> chain2;
        List<String> chain3;

        chain1.add("Rubén");
        chain1.add("Alberto");
        chain2.add("corre");
        chain2.add("salta");
        chain3.add("por la tarde");
        chain3.add("por la mañana");

 */

        String current_sentence = " ";
        String final_sentence = " ";

        Collections.sort(subjects);
        Collections.sort(verbs);
        Collections.sort(objects);

        for (String name : subjects) {
            for (String verb : verbs) {
                for (String object : objects) {
                    current_sentence = name + ' ' + verb + ' ' + object + ".";
                    final_sentence += " " + current_sentence;
                }
            }
        }

        return  final_sentence.trim();
    }
}