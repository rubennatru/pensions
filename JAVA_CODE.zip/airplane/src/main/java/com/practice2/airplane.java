package com.practice2;

public class airplane {

    public float fuel_level;
    public int consumption;
    public int position[];


    public airplane(float fuel_level, int consumption, int[] position) {
        this.fuel_level= fuel_level;
        this.consumption = consumption;
        this.position = position;
    }


    public boolean go_to(int[] future_pos) {
        int distance = ((future_pos[1] - this.position[1]) ^ 2) + ((future_pos[0] - this.position[0]) ^ 2);

        if (this.fuel_level >= (distance * this.consumption)) {
            this.position = future_pos;
            this.fuel_level = this.fuel_level - (distance * this.consumption);
            return true;
        }
        else{
            return false;
        }
    }

    public float refuel(int amount){
        float future_level = this.fuel_level + amount;

        if ((this.fuel_level < 100.0) && (future_level <= 100.0)) {
            this.fuel_level = future_level;
        }
        else{
            this.fuel_level = 100;
        }
        return this.fuel_level;
    }

    public static void main(String[] args){

        /*
           ---  UNIT TEST ---

        int[] init_pos = {0,0};
        airplane my_plane = new airplane(100,3, init_pos);
        int[] pos = my_plane.position;
        int[] future_pos = {8,8};
        my_plane.go_to(future_pos);
        my_plane.refuel(50);

         */
    }
}
