package com.practice2;
import static org.junit.Assert.*;
import org.junit.Test;

public class test_airplane {

    @Test
    public void test_go_to1() {
        int cons = 3;
        int[] pos = {0,0};
        float level = 100.0f;
        airplane myplane = new airplane(level, cons, pos);
        int[] future_pos = {8,8};
        myplane.position = future_pos;
        assertEquals(true, myplane.go_to(future_pos));
    }


    @Test
    public void test_go_to2() {
        int cons = 3;
        int[] pos = {0,0};
        float level = 100.0f;
        airplane myplane = new airplane(level, cons, pos);
        int[] future_pos = {80,80};
        myplane.position = future_pos;
        assertEquals(true, myplane.go_to(future_pos));
    }

    @Test
    public void test_refuel() {
        int cons = 3;
        int []pos = {0,0};
        float level = 20.0f;
        int amount_refuel = 100;
        airplane myplane = new airplane(level, cons, pos);
        assertEquals(100.0f, myplane.refuel(amount_refuel), 0.001);
    }
}


